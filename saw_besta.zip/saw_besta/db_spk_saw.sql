-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 05, 2020 at 05:02 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_spk_saw`
--

-- --------------------------------------------------------

--
-- Table structure for table `alternatif`
--

CREATE TABLE `alternatif` (
  `id_alternatif` int(11) NOT NULL,
  `nama_alternatif` varchar(255) NOT NULL,
  `hasil_alternatif` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alternatif`
--

INSERT INTO `alternatif` (`id_alternatif`, `nama_alternatif`, `hasil_alternatif`) VALUES
(7, 'Feri Sayati', 100),
(8, 'Sri Kastumi', 30),
(9, 'Narsi', 61.5),
(10, 'Susanti', 90),
(11, 'Suyatmi', 65.5),
(12, 'Supamini', 75),
(13, 'Rita Pujiati', 82.5),
(14, 'Riyaten', 75.5),
(15, 'Lastri', 46.5),
(16, 'Istiningsih', 68.5),
(17, 'Indarwati', 57),
(18, 'Umowati', 51),
(19, 'Sulis Sriana', 51),
(20, 'Sulistari', 67.5),
(21, 'Sari Damayanti', 100),
(22, 'Dian Puspa Rina', 100),
(23, 'Shofiah', 60),
(24, 'Suprakti', 60),
(25, 'Sapa ah', 60),
(26, 'Mutmainah', 42),
(27, 'Sukaryati', 92.5),
(28, 'Rumiasih', 100),
(29, 'Sutik Sulistiyaningsih', 100),
(30, 'Suhartini', 100),
(31, 'Siti Utami', 100),
(32, 'Sayekti', 30),
(33, 'Siti Jaenab', 30),
(34, 'Rinawati Youmeidha', 30),
(35, 'Putri Ningsih', 60),
(36, 'Alsum Juwariyah', 60),
(37, 'Yayuk Lestari', 67.5),
(38, 'Endang Purwati', 100),
(39, 'Istiqomah', 82.5),
(40, 'Weni Noryati', 92.5),
(41, 'Tatin Sudiarti', 39),
(42, 'Tiana', 60),
(43, 'Kartini A', 67.5),
(44, 'Masripah', 100),
(45, 'Paridawati', 100),
(46, 'Winarsih', 70.5),
(47, 'Juriyah', 70.5),
(48, 'Suyati', 78),
(49, 'Juminten', 69),
(50, 'Kasni', 30),
(51, 'Lis Murni', 30),
(52, 'Sriyanto', 92.5),
(53, 'Dwi Lusiati', 30),
(54, 'Sukaryono', 30),
(55, 'Isti Dewi Wijayani', 75.5),
(56, 'Sunarti', 64.5),
(57, 'Adit', 70.5),
(59, 'EGA ANGGER', 31.5);

-- --------------------------------------------------------

--
-- Table structure for table `kriteria`
--

CREATE TABLE `kriteria` (
  `id_kriteria` int(11) NOT NULL,
  `nama_kriteria` varchar(255) NOT NULL,
  `tipe_kriteria` varchar(10) NOT NULL,
  `bobot_kriteria` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kriteria`
--

INSERT INTO `kriteria` (`id_kriteria`, `nama_kriteria`, `tipe_kriteria`, `bobot_kriteria`) VALUES
(2, 'Kinerja', 'Benefit', 20),
(3, 'Kedisiplinan', 'Benefit', 30),
(4, 'Karakter', 'Benefit', 10),
(5, 'Kreatifitas', 'Benefit', 10),
(6, 'Absensi', 'Benefit', 30);

-- --------------------------------------------------------

--
-- Table structure for table `nilai`
--

CREATE TABLE `nilai` (
  `id_nilai` int(6) NOT NULL,
  `ket_nilai` varchar(45) NOT NULL,
  `jum_nilai` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nilai`
--

INSERT INTO `nilai` (`id_nilai`, `ket_nilai`, `jum_nilai`) VALUES
(1, '>75', 100),
(2, '75', 60),
(3, '<75', 30),
(4, 'Sangat Baik', 100),
(5, 'Baik', 75),
(6, 'Cukup Baik', 60),
(7, 'Kurang Baik', 30);

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` int(11) NOT NULL,
  `nama_lengkap` varchar(255) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `nama_lengkap`, `username`, `password`) VALUES
(1, 'Admin', 'admin', 'c3284d0f94606de1fd2af172aba15bf3'),
(2, 'admin', 'admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `rangking`
--

CREATE TABLE `rangking` (
  `id_alternatif` int(11) NOT NULL,
  `id_kriteria` int(11) NOT NULL,
  `nilai_rangking` double NOT NULL,
  `nilai_normalisasi` double NOT NULL,
  `bobot_normalisasi` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rangking`
--

INSERT INTO `rangking` (`id_alternatif`, `id_kriteria`, `nilai_rangking`, `nilai_normalisasi`, `bobot_normalisasi`) VALUES
(7, 2, 100, 1, 20),
(7, 3, 100, 1, 30),
(7, 4, 100, 1, 10),
(7, 5, 100, 1, 10),
(7, 6, 100, 1, 30),
(8, 2, 30, 0.3, 6),
(8, 3, 30, 0.3, 9),
(8, 4, 30, 0.3, 3),
(8, 5, 30, 0.3, 3),
(8, 6, 30, 0.3, 9),
(9, 2, 75, 0.75, 15),
(9, 3, 60, 0.6, 18),
(9, 4, 75, 0.75, 7.5),
(9, 5, 30, 0.3, 3),
(9, 6, 60, 0.6, 18),
(10, 2, 75, 0.75, 15),
(10, 3, 100, 1, 30),
(10, 4, 75, 0.75, 7.5),
(10, 5, 75, 0.75, 7.5),
(10, 6, 100, 1, 30),
(11, 2, 60, 0.6, 12),
(11, 3, 60, 0.6, 18),
(11, 4, 75, 0.75, 7.5),
(11, 5, 100, 1, 10),
(11, 6, 60, 0.6, 18),
(12, 2, 75, 0.75, 15),
(12, 3, 100, 1, 30),
(12, 4, 60, 0.6, 6),
(12, 5, 60, 0.6, 6),
(12, 6, 60, 0.6, 18),
(13, 2, 75, 0.75, 15),
(13, 3, 75, 0.75, 22.5),
(13, 4, 75, 0.75, 7.5),
(13, 5, 75, 0.75, 7.5),
(13, 6, 100, 1, 30),
(14, 2, 100, 1, 20),
(14, 3, 75, 0.75, 22.5),
(14, 4, 75, 0.75, 7.5),
(14, 5, 75, 0.75, 7.5),
(14, 6, 60, 0.6, 18),
(15, 2, 30, 0.3, 6),
(15, 3, 60, 0.6, 18),
(15, 4, 60, 0.6, 6),
(15, 5, 75, 0.75, 7.5),
(15, 6, 30, 0.3, 9),
(16, 2, 60, 0.6, 12),
(16, 3, 75, 0.75, 22.5),
(16, 4, 100, 1, 10),
(16, 5, 60, 0.6, 6),
(16, 6, 60, 0.6, 18),
(17, 2, 60, 0.6, 12),
(17, 3, 30, 0.3, 9),
(17, 4, 30, 0.3, 3),
(17, 5, 30, 0.3, 3),
(17, 6, 100, 1, 30),
(18, 2, 30, 0.3, 6),
(18, 3, 30, 0.3, 9),
(18, 4, 30, 0.3, 3),
(18, 5, 30, 0.3, 3),
(18, 6, 100, 1, 30),
(19, 2, 30, 0.3, 6),
(19, 3, 30, 0.3, 9),
(19, 4, 30, 0.3, 3),
(19, 5, 30, 0.3, 3),
(19, 6, 100, 1, 30),
(20, 2, 75, 0.75, 15),
(20, 3, 75, 0.75, 22.5),
(20, 4, 60, 0.6, 6),
(20, 5, 60, 0.6, 6),
(20, 6, 60, 0.6, 18),
(21, 2, 100, 1, 20),
(21, 3, 100, 1, 30),
(21, 4, 100, 1, 10),
(21, 5, 100, 1, 10),
(21, 6, 100, 1, 30),
(22, 2, 100, 1, 20),
(22, 3, 100, 1, 30),
(22, 4, 100, 1, 10),
(22, 5, 100, 1, 10),
(22, 6, 100, 1, 30),
(23, 2, 60, 0.6, 12),
(23, 3, 60, 0.6, 18),
(23, 4, 60, 0.6, 6),
(23, 5, 60, 0.6, 6),
(23, 6, 60, 0.6, 18),
(24, 2, 60, 0.6, 12),
(24, 3, 60, 0.6, 18),
(24, 4, 60, 0.6, 6),
(24, 5, 60, 0.6, 6),
(24, 6, 60, 0.6, 18),
(25, 2, 60, 0.6, 12),
(25, 3, 60, 0.6, 18),
(25, 4, 60, 0.6, 6),
(25, 5, 60, 0.6, 6),
(25, 6, 60, 0.6, 18),
(26, 2, 60, 0.6, 12),
(26, 3, 30, 0.3, 9),
(26, 4, 60, 0.6, 6),
(26, 5, 60, 0.6, 6),
(26, 6, 30, 0.3, 9),
(27, 2, 75, 0.75, 15),
(27, 3, 100, 1, 30),
(27, 4, 75, 0.75, 7.5),
(27, 5, 100, 1, 10),
(27, 6, 100, 1, 30),
(28, 2, 100, 1, 20),
(28, 3, 100, 1, 30),
(28, 4, 100, 1, 10),
(28, 5, 100, 1, 10),
(28, 6, 100, 1, 30),
(29, 2, 100, 1, 20),
(29, 3, 100, 1, 30),
(29, 4, 100, 1, 10),
(29, 5, 100, 1, 10),
(29, 6, 100, 1, 30),
(30, 2, 100, 1, 20),
(30, 3, 100, 1, 30),
(30, 4, 100, 1, 10),
(30, 5, 100, 1, 10),
(30, 6, 100, 1, 30),
(31, 2, 100, 1, 20),
(31, 3, 100, 1, 30),
(31, 4, 100, 1, 10),
(31, 5, 100, 1, 10),
(31, 6, 100, 1, 30),
(32, 2, 30, 0.3, 6),
(32, 3, 30, 0.3, 9),
(32, 4, 30, 0.3, 3),
(32, 5, 30, 0.3, 3),
(32, 6, 30, 0.3, 9),
(33, 2, 30, 0.3, 6),
(33, 3, 30, 0.3, 9),
(33, 4, 30, 0.3, 3),
(33, 5, 30, 0.3, 3),
(33, 6, 30, 0.3, 9),
(34, 2, 30, 0.3, 6),
(34, 3, 30, 0.3, 9),
(34, 4, 30, 0.3, 3),
(34, 5, 30, 0.3, 3),
(34, 6, 30, 0.3, 9),
(35, 2, 60, 0.6, 12),
(35, 3, 60, 0.6, 18),
(35, 4, 60, 0.6, 6),
(35, 5, 60, 0.6, 6),
(35, 6, 60, 0.6, 18),
(36, 2, 60, 0.6, 12),
(36, 3, 60, 0.6, 18),
(36, 4, 60, 0.6, 6),
(36, 5, 60, 0.6, 6),
(36, 6, 60, 0.6, 18),
(37, 2, 75, 0.75, 15),
(37, 3, 75, 0.75, 22.5),
(37, 4, 60, 0.6, 6),
(37, 5, 60, 0.6, 6),
(37, 6, 60, 0.6, 18),
(38, 2, 100, 1, 20),
(38, 3, 100, 1, 30),
(38, 4, 100, 1, 10),
(38, 5, 100, 1, 10),
(38, 6, 100, 1, 30),
(39, 2, 75, 0.75, 15),
(39, 3, 75, 0.75, 22.5),
(39, 4, 75, 0.75, 7.5),
(39, 5, 75, 0.75, 7.5),
(39, 6, 100, 1, 30),
(40, 2, 75, 0.75, 15),
(40, 3, 100, 1, 30),
(40, 4, 100, 1, 10),
(40, 5, 75, 0.75, 7.5),
(40, 6, 100, 1, 30),
(41, 2, 30, 0.3, 6),
(41, 3, 60, 0.6, 18),
(41, 4, 30, 0.3, 3),
(41, 5, 30, 0.3, 3),
(41, 6, 30, 0.3, 9),
(42, 2, 60, 0.6, 12),
(42, 3, 60, 0.6, 18),
(42, 4, 60, 0.6, 6),
(42, 5, 60, 0.6, 6),
(42, 6, 60, 0.6, 18),
(43, 2, 75, 0.75, 15),
(43, 3, 75, 0.75, 22.5),
(43, 4, 60, 0.6, 6),
(43, 5, 60, 0.6, 6),
(43, 6, 60, 0.6, 18),
(44, 2, 100, 1, 20),
(44, 3, 100, 1, 30),
(44, 4, 100, 1, 10),
(44, 5, 100, 1, 10),
(44, 6, 100, 1, 30),
(45, 2, 100, 1, 20),
(45, 3, 100, 1, 30),
(45, 4, 100, 1, 10),
(45, 5, 100, 1, 10),
(45, 6, 100, 1, 30),
(46, 2, 75, 0.75, 15),
(46, 3, 75, 0.75, 22.5),
(46, 4, 75, 0.75, 7.5),
(46, 5, 75, 0.75, 7.5),
(46, 6, 60, 0.6, 18),
(47, 2, 75, 0.75, 15),
(47, 3, 75, 0.75, 22.5),
(47, 4, 75, 0.75, 7.5),
(47, 5, 75, 0.75, 7.5),
(47, 6, 60, 0.6, 18),
(48, 2, 100, 1, 20),
(48, 3, 75, 0.75, 22.5),
(48, 4, 100, 1, 10),
(48, 5, 75, 0.75, 7.5),
(48, 6, 60, 0.6, 18),
(49, 2, 75, 0.75, 15),
(49, 3, 75, 0.75, 22.5),
(49, 4, 60, 0.6, 6),
(49, 5, 75, 0.75, 7.5),
(49, 6, 60, 0.6, 18),
(50, 2, 30, 0.3, 6),
(50, 3, 30, 0.3, 9),
(50, 4, 30, 0.3, 3),
(50, 5, 30, 0.3, 3),
(50, 6, 30, 0.3, 9),
(51, 2, 30, 0.3, 6),
(51, 3, 30, 0.3, 9),
(51, 4, 30, 0.3, 3),
(51, 5, 30, 0.3, 3),
(51, 6, 30, 0.3, 9),
(52, 2, 75, 0.75, 15),
(52, 3, 100, 1, 30),
(52, 4, 100, 1, 10),
(52, 5, 75, 0.75, 7.5),
(52, 6, 100, 1, 30),
(53, 2, 30, 0.3, 6),
(53, 3, 30, 0.3, 9),
(53, 4, 30, 0.3, 3),
(53, 5, 30, 0.3, 3),
(53, 6, 30, 0.3, 9),
(54, 2, 30, 0.3, 6),
(54, 3, 30, 0.3, 9),
(54, 4, 30, 0.3, 3),
(54, 5, 30, 0.3, 3),
(54, 6, 30, 0.3, 9),
(55, 2, 100, 1, 20),
(55, 3, 75, 0.75, 22.5),
(55, 4, 75, 0.75, 7.5),
(55, 5, 75, 0.75, 7.5),
(55, 6, 60, 0.6, 18),
(56, 2, 75, 0.75, 15),
(56, 3, 60, 0.6, 18),
(56, 4, 60, 0.6, 6),
(56, 5, 75, 0.75, 7.5),
(56, 6, 60, 0.6, 18),
(57, 2, 75, 0.75, 15),
(57, 3, 75, 0.75, 22.5),
(57, 4, 75, 0.75, 7.5),
(57, 5, 75, 0.75, 7.5),
(57, 6, 60, 0.6, 18),
(59, 3, 75, 0.75, 22.5),
(59, 6, 30, 0.3, 9);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alternatif`
--
ALTER TABLE `alternatif`
  ADD PRIMARY KEY (`id_alternatif`);

--
-- Indexes for table `kriteria`
--
ALTER TABLE `kriteria`
  ADD PRIMARY KEY (`id_kriteria`);

--
-- Indexes for table `nilai`
--
ALTER TABLE `nilai`
  ADD PRIMARY KEY (`id_nilai`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`);

--
-- Indexes for table `rangking`
--
ALTER TABLE `rangking`
  ADD PRIMARY KEY (`id_alternatif`,`id_kriteria`),
  ADD KEY `id_kriteria` (`id_kriteria`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alternatif`
--
ALTER TABLE `alternatif`
  MODIFY `id_alternatif` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `kriteria`
--
ALTER TABLE `kriteria`
  MODIFY `id_kriteria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `nilai`
--
ALTER TABLE `nilai`
  MODIFY `id_nilai` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_pengguna` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `rangking`
--
ALTER TABLE `rangking`
  ADD CONSTRAINT `rangking_ibfk_1` FOREIGN KEY (`id_alternatif`) REFERENCES `alternatif` (`id_alternatif`),
  ADD CONSTRAINT `rangking_ibfk_2` FOREIGN KEY (`id_kriteria`) REFERENCES `kriteria` (`id_kriteria`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
