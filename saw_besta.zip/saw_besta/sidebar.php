	<div class="panel panel-default">
		<div class="panel-body">
			<h5>Penjelasan Singkat</h5>
			<hr/>
			Aplikasi ini adalah aplikasi sistem pendukung keputusan dengan metode saw (simple additive weighting) yang mengharuskan
			untuk menginput nilai dulu kemudian baru kriteria dan selanjutnya adalah alternatif dan tahap akhir dengan melakukan
			perangkingan pada rangking dan melihat laporan hasil akhir.<p>&nbsp;</p>
			<h5>Tutorial SAW</h5>
			<hr/>
			<video src="images/dss.webm" width="100%" height="200" controls></video>
		</div>
	</div>